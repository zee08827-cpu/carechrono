"""
CareChrono - FastAPI Backend Server
Patient-centred web application for chronic disease care.
Stack: Python, FastAPI, SQLAlchemy, Pydantic, PostgreSQL (Supabase) / SQLite.
"""
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import engine, Base, SessionLocal
from .models import User
from .seed import seed_database
from .routers import (
    auth_routes,
    consultations_routes,
    vitals_routes,
    medications_routes,
    records_routes,
    thresholds_routes,
    alerts_routes,
    caregiver_routes
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: ensure tables exist and auto-seed if database is empty
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    user_count = db.query(User).count()
    if user_count == 0:
        print("[INFO] Database is empty. Auto-seeding initial demo data...")
        seed_database()
    db.close()
    yield

app = FastAPI(
    title="CareChrono API",
    description="Empowering chronic disease patients beyond medical storage: consultation diffs, continuous monitoring, and clinician-approved smart alerts.",
    version="1.0.0",
    lifespan=lifespan
)

# CORS configuration
origins = os.getenv("CORS_ORIGINS", "http://localhost:5173,http://localhost:3000,http://127.0.0.1:5173").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Open for development / hackathon testing
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
app.include_router(auth_routes.router)
app.include_router(consultations_routes.router)
app.include_router(vitals_routes.router)
app.include_router(medications_routes.router)
app.include_router(records_routes.router)
app.include_router(thresholds_routes.router)
app.include_router(alerts_routes.router)
app.include_router(caregiver_routes.router)

@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "app": "CareChrono",
        "safety_disclaimer": "CareChrono is an assistive tool and does not provide medical diagnoses or replace clinical advice."
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
