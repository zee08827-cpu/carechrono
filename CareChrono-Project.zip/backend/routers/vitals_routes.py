"""
CareChrono - Continuous Vitals Monitoring Route
Handles vital readings, trend computations, sparklines, and triggers clinician-approved alerts.
"""
from datetime import datetime, timedelta
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User, VitalReading, ClinicianThreshold, SmartAlert
from ..schemas import (
    VitalReadingCreate, VitalReadingOut, MetricTrendData, SparklinePoint
)
from ..auth import get_current_user, verify_patient_access

router = APIRouter(prefix="/api/vitals", tags=["Vitals"])

def evaluate_reading_against_thresholds(reading: VitalReading, db: Session):
    """
    Evaluates newly logged vital reading against clinician-approved thresholds.
    Adheres strictly to CareChrono safety rules:
    - Never diagnoses
    - Phrases alerts as 'attention may be needed'
    - Critical alerts flag caregiver notification
    """
    # Look for patient-specific threshold or fall back to system threshold
    threshold = db.query(ClinicianThreshold).filter(
        (ClinicianThreshold.patient_id == reading.patient_id) | (ClinicianThreshold.patient_id == None),
        ClinicianThreshold.metric_type == reading.metric_type
    ).first()

    if not threshold:
        return

    val = reading.value
    is_critical = False
    is_warning = False
    msg = ""

    if threshold.critical_max and val >= threshold.critical_max:
        is_critical = True
        msg = f"Reading of {val:g} {reading.unit} is notably above your clinician-approved target ({threshold.target_max:g} {reading.unit}). Attention may be needed; please rest and recheck, or contact your care team if this persists."
    elif threshold.critical_min and val <= threshold.critical_min:
        is_critical = True
        msg = f"Reading of {val:g} {reading.unit} is below your clinician-approved minimum ({threshold.target_min:g} {reading.unit}). Attention may be needed; please take prescribed fast-acting measures as guided by your doctor."
    elif threshold.warning_max and val >= threshold.warning_max:
        is_warning = True
        msg = f"Reading of {val:g} {reading.unit} is above your typical target. Attention may be needed; monitor closely over your next scheduled check."
    elif threshold.warning_min and val <= threshold.warning_min:
        is_warning = True
        msg = f"Reading of {val:g} {reading.unit} is slightly lower than your target. Attention may be needed."

    # For Blood pressure, also check secondary diastolic value
    if reading.metric_type == "blood_pressure" and reading.secondary_value:
        dia_val = reading.secondary_value
        if dia_val >= 95:
            is_critical = True
            msg = f"Diastolic reading of {dia_val:g} mmHg is elevated. Attention may be needed; please follow your clinician's guidance."
        elif dia_val >= 85 and not is_critical:
            is_warning = True
            msg = f"Diastolic reading of {dia_val:g} mmHg is slightly above target. Attention may be needed."

    if is_critical or is_warning:
        target_display = f"{threshold.target_min or 0} - {threshold.target_max or 0} {threshold.unit}"
        alert = SmartAlert(
            patient_id=reading.patient_id,
            reading_id=reading.id,
            severity="critical" if is_critical else "warning",
            metric_type=reading.metric_type,
            title=f"Attention may be needed: {reading.metric_type.replace('_', ' ').title()}",
            message=msg,
            measured_value=f"{val:g}{' / ' + str(int(reading.secondary_value)) if reading.secondary_value else ''} {reading.unit}",
            clinician_target=f"Target: {target_display} (Approved by {threshold.approved_by_name})",
            is_acknowledged=False,
            caregiver_notified=is_critical
        )
        db.add(alert)
        db.commit()

@router.post("", response_model=VitalReadingOut)
def log_vital_reading(
    reading_in: VitalReadingCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    target_patient_id = reading_in.patient_id or current_user.id
    if not verify_patient_access(target_patient_id, current_user, db):
        raise HTTPException(status_code=403, detail="Not authorized to log vitals for this patient")

    reading = VitalReading(
        patient_id=target_patient_id,
        metric_type=reading_in.metric_type,
        value=reading_in.value,
        secondary_value=reading_in.secondary_value,
        unit=reading_in.unit,
        context=reading_in.context,
        notes=reading_in.notes,
        logged_by=current_user.role
    )
    db.add(reading)
    db.commit()
    db.refresh(reading)

    # Check for threshold alerts
    evaluate_reading_against_thresholds(reading, db)

    return reading

@router.get("/trends", response_model=List[MetricTrendData])
def get_vitals_trends(
    patient_id: Optional[int] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Returns aggregated continuous monitoring trend metrics, history sparklines,
    and clinician target lines for Recharts visualization.
    """
    target_patient_id = patient_id or (current_user.id if current_user.role == "patient" else None)
    if not target_patient_id:
        patient = db.query(User).filter(User.role == "patient").first()
        target_patient_id = patient.id if patient else current_user.id

    if not verify_patient_access(target_patient_id, current_user, db):
        raise HTTPException(status_code=403, detail="Not authorized to access vitals")

    metrics_config = [
        {"type": "blood_pressure", "label": "Blood Pressure", "unit": "mmHg", "target": 125.0, "target_text": "Target < 130/80 mmHg"},
        {"type": "blood_glucose", "label": "Blood Glucose (Fasting)", "unit": "mg/dL", "target": 110.0, "target_text": "Target 90 - 130 mg/dL"},
        {"type": "heart_rate", "label": "Resting Heart Rate", "unit": "bpm", "target": 72.0, "target_text": "Target 60 - 85 bpm"},
        {"type": "weight", "label": "Body Weight", "unit": "kg", "target": 78.0, "target_text": "Target < 80.0 kg"}
    ]

    result: List[MetricTrendData] = []

    for cfg in metrics_config:
        mtype = cfg["type"]
        readings = db.query(VitalReading).filter(
            VitalReading.patient_id == target_patient_id,
            VitalReading.metric_type == mtype
        ).order_by(VitalReading.logged_at.asc()).all()

        if not readings:
            # Empty fallback
            result.append(MetricTrendData(
                metric_type=mtype,
                label=cfg["label"],
                unit=cfg["unit"],
                latest_value=cfg["target"],
                latest_secondary_value=80.0 if mtype == "blood_pressure" else None,
                status="normal",
                average_target=cfg["target"],
                clinician_target_text=cfg["target_text"],
                history=[],
                change_vs_last_week_pct=0.0,
                is_improved=True
            ))
            continue

        latest = readings[-1]
        sparkline = [
            SparklinePoint(
                date=r.logged_at.strftime("%b %d"),
                value=round(r.value, 1),
                secondary_value=round(r.secondary_value, 1) if r.secondary_value else None
            )
            for r in readings[-14:]  # Last 14 days
        ]

        # Determine status
        status = "normal"
        is_improved = True
        pct_change = 0.0

        if len(readings) >= 2:
            prev = readings[-2]
            if prev.value > 0:
                pct_change = round(((latest.value - prev.value) / prev.value) * 100, 1)

        if mtype == "blood_pressure":
            if latest.value >= 140 or (latest.secondary_value and latest.secondary_value >= 90):
                status = "needs_attention"
                is_improved = False
            elif latest.value <= 130:
                status = "improved"
                is_improved = True
        elif mtype == "blood_glucose":
            if latest.value >= 135:
                status = "needs_attention"
                is_improved = False
            elif latest.value <= 120:
                status = "improved"
                is_improved = True

        result.append(MetricTrendData(
            metric_type=mtype,
            label=cfg["label"],
            unit=cfg["unit"],
            latest_value=latest.value,
            latest_secondary_value=latest.secondary_value,
            status=status,
            average_target=cfg["target"],
            clinician_target_text=cfg["target_text"],
            history=sparkline,
            change_vs_last_week_pct=pct_change,
            is_improved=is_improved
        ))

    return result

@router.get("/history", response_model=List[VitalReadingOut])
def get_vitals_history(
    metric_type: Optional[str] = None,
    patient_id: Optional[int] = None,
    limit: int = 30,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    target_patient_id = patient_id or (current_user.id if current_user.role == "patient" else None)
    if not target_patient_id:
        patient = db.query(User).filter(User.role == "patient").first()
        target_patient_id = patient.id if patient else current_user.id

    if not verify_patient_access(target_patient_id, current_user, db):
        raise HTTPException(status_code=403, detail="Not authorized to access vitals")

    query = db.query(VitalReading).filter(VitalReading.patient_id == target_patient_id)
    if metric_type:
        query = query.filter(VitalReading.metric_type == metric_type)

    return query.order_by(VitalReading.logged_at.desc()).limit(limit).all()
