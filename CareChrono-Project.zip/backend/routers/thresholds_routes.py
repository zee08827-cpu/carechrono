"""
CareChrono - Clinician-Approved Thresholds Route
Enables doctors to view, approve, and calibrate clinical alert boundaries for chronic patients.
"""
from typing import List, Optional
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User, ClinicianThreshold
from ..schemas import ClinicianThresholdOut, ClinicianThresholdUpdate
from ..auth import get_current_user, require_role

router = APIRouter(prefix="/api/thresholds", tags=["Thresholds"])

@router.get("", response_model=List[ClinicianThresholdOut])
def get_thresholds(
    patient_id: Optional[int] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Returns active clinician-approved thresholds for the patient or system defaults."""
    query = db.query(ClinicianThreshold)
    if patient_id:
        query = query.filter((ClinicianThreshold.patient_id == patient_id) | (ClinicianThreshold.patient_id == None))
    return query.all()

@router.put("/{threshold_id}", response_model=ClinicianThresholdOut)
def update_threshold(
    threshold_id: int,
    payload: ClinicianThresholdUpdate,
    current_user: User = Depends(require_role(["doctor"])),
    db: Session = Depends(get_db)
):
    """
    Clinician threshold update: Restricted strictly to doctor role.
    Ensures smart alerts are always based on certified clinical judgement.
    """
    threshold = db.query(ClinicianThreshold).filter(ClinicianThreshold.id == threshold_id).first()
    if not threshold:
        raise HTTPException(status_code=404, detail="Threshold not found")

    if payload.target_min is not None:
        threshold.target_min = payload.target_min
    if payload.target_max is not None:
        threshold.target_max = payload.target_max
    if payload.warning_min is not None:
        threshold.warning_min = payload.warning_min
    if payload.warning_max is not None:
        threshold.warning_max = payload.warning_max
    if payload.critical_min is not None:
        threshold.critical_min = payload.critical_min
    if payload.critical_max is not None:
        threshold.critical_max = payload.critical_max
    if payload.clinical_rationale is not None:
        threshold.clinical_rationale = payload.clinical_rationale

    threshold.is_approved = True
    threshold.approved_by_name = current_user.full_name
    threshold.doctor_id = current_user.id
    threshold.updated_at = datetime.utcnow()

    db.commit()
    db.refresh(threshold)
    return threshold
