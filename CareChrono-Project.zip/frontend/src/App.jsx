import React, { useState } from 'react';
import { useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { MedicalDisclaimerFooter } from './components/MedicalDisclaimerFooter';
import { Dashboard } from './pages/Dashboard';
import { ConsultationCompare } from './pages/ConsultationCompare';
import { ContinuousMonitoring } from './pages/ContinuousMonitoring';
import { MedicationsPage } from './pages/MedicationsPage';
import { HealthRecordsPage } from './pages/HealthRecordsPage';
import { ThresholdsAndAlertsPage } from './pages/ThresholdsAndAlertsPage';
import { CaregiverConsentPage } from './pages/CaregiverConsentPage';
import { SeniorModeView } from './pages/SeniorModeView';

export function App() {
  const { user, isSeniorMode, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  // If Senior Mode is activated, render the dedicated accessible flat view
  if (isSeniorMode) {
    return <SeniorModeView />;
  }

  if (loading && !user) {
    return (
      <div className="min-h-screen bg-canvas flex items-center justify-center text-teal-dark">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 border-4 border-teal-dark border-t-mint rounded-full animate-spin mx-auto" />
          <p className="font-bold text-sm">Loading CareChrono Health Profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-canvas flex flex-col justify-between">
      <div>
        {/* Top Sticky Navigation */}
        <Navbar
          onOpenAlerts={() => setActiveTab('thresholds')}
          alertCount={1}
        />

        {/* Main Workspace Page Container */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-28">
          {activeTab === 'dashboard' && <Dashboard onSelectTab={setActiveTab} />}
          {activeTab === 'compare' && <ConsultationCompare />}
          {activeTab === 'trends' && <ContinuousMonitoring />}
          {activeTab === 'meds' && <MedicationsPage />}
          {activeTab === 'records' && <HealthRecordsPage />}
          {activeTab === 'thresholds' && <ThresholdsAndAlertsPage />}
          {activeTab === 'consent' && <CaregiverConsentPage />}
        </main>
      </div>

      {/* Floating Pill Bottom Navigation (Dribbble Design Reference) */}
      <BottomNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        role={user?.role}
      />

      {/* Safety Rule: Non-diagnostic medical governance disclaimer footer on every view */}
      <MedicalDisclaimerFooter />
    </div>
  );
}

export default App;
