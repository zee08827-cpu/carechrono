import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  ShieldCheck, 
  AlertTriangle, 
  AlertCircle, 
  CheckCircle2, 
  Bell, 
  Edit3, 
  Save, 
  Lock,
  Stethoscope,
  Info
} from 'lucide-react';

export const ThresholdsAndAlertsPage = () => {
  const { authFetch, user } = useAuth();
  const [thresholds, setThresholds] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [editValues, setEditValues] = useState({});
  const [feedback, setFeedback] = useState('');
  const [loading, setLoading] = useState(true);

  const isDoctor = user?.role === 'doctor';

  const fetchData = async () => {
    try {
      const [tRes, aRes] = await Promise.all([
        authFetch('/api/thresholds'),
        authFetch('/api/alerts')
      ]);
      if (tRes.ok) setThresholds(await tRes.json());
      if (aRes.ok) setAlerts(await aRes.json());
    } catch (e) {
      console.error('Error fetching alerts/thresholds:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAcknowledge = async (alertId) => {
    try {
      const res = await authFetch(`/api/alerts/${alertId}/acknowledge`, { method: 'POST' });
      if (res.ok) {
        fetchData();
      }
    } catch (e) {
      console.error('Error acknowledging alert:', e);
    }
  };

  const handleStartEdit = (t) => {
    setEditingId(t.id);
    setEditValues({
      target_max: t.target_max,
      warning_max: t.warning_max,
      critical_max: t.critical_max,
      clinical_rationale: t.clinical_rationale || ''
    });
  };

  const handleSaveThreshold = async (thresholdId) => {
    try {
      const res = await authFetch(`/api/thresholds/${thresholdId}`, {
        method: 'PUT',
        body: JSON.stringify(editValues)
      });
      if (res.ok) {
        setFeedback('Clinician threshold updated and approved.');
        setTimeout(() => setFeedback(''), 3000);
        setEditingId(null);
        fetchData();
      }
    } catch (e) {
      console.error('Failed to update threshold:', e);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-canvas-card rounded-card p-6 border border-teal-dark/10 shadow-soft">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-mint text-teal-dark flex items-center justify-center shadow-pill">
              <ShieldCheck className="w-6 h-6 text-teal-dark" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-teal-dark">Smart Alerts & Clinician Thresholds</h1>
              <p className="text-sm text-teal-dark/70">
                Non-diagnostic assistive safety monitors governed by certified clinical targets.
              </p>
            </div>
          </div>

          {/* Clinician badge */}
          <div className="inline-flex items-center gap-2 bg-white px-3.5 py-1.5 rounded-full border border-teal-dark/15 text-xs font-semibold text-teal-dark">
            <Stethoscope className="w-4 h-4 text-teal-dark" />
            <span>Active Approver: Dr. Richard Chen, MD</span>
          </div>
        </div>
      </div>

      {feedback && (
        <div className="p-3 bg-mint text-teal-dark rounded-2xl text-xs font-bold flex items-center gap-2 shadow-soft">
          <CheckCircle2 className="w-4 h-4 text-teal-dark" />
          <span>{feedback}</span>
        </div>
      )}

      {/* SECTION 1: Active Smart Alerts */}
      <div className="bg-white rounded-card p-6 border border-teal-dark/10 shadow-soft space-y-4">
        <div className="flex items-center justify-between border-b border-teal-dark/10 pb-3">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-teal-dark" />
            <h2 className="text-lg font-bold text-teal-dark">Active Safety Alerts</h2>
          </div>
          <span className="text-xs bg-canvas-subtle text-teal-dark/70 px-3 py-1 rounded-full font-bold">
            {alerts.filter(a => !a.is_acknowledged).length} Pending Attention
          </span>
        </div>

        <div className="space-y-3">
          {alerts.length === 0 ? (
            <p className="text-xs text-teal-dark/60 py-4 text-center">
              No active alerts. All vital readings are within clinician-approved targets.
            </p>
          ) : (
            alerts.map((al) => {
              const isCritical = al.severity === 'critical';
              return (
                <div
                  key={al.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    isCritical
                      ? 'bg-coral-critical/10 border-coral-critical/40'
                      : 'bg-coral/10 border-coral/30'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className={`p-2 rounded-full mt-0.5 ${
                        isCritical ? 'bg-coral-critical text-white' : 'bg-coral text-teal-dark'
                      }`}>
                        {isCritical ? (
                          <AlertTriangle className="w-4 h-4 text-white" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-teal-dark" />
                        )}
                      </div>

                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className={`text-xs font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                            isCritical ? 'bg-coral-critical text-white' : 'bg-coral text-teal-dark font-bold'
                          }`}>
                            {isCritical ? 'CRITICAL ATTENTION' : 'ATTENTION MAY BE NEEDED'}
                          </span>
                          <span className="text-xs font-bold text-teal-dark">
                            Measured: {al.measured_value}
                          </span>
                          {al.caregiver_notified && (
                            <span className="text-[10px] font-bold bg-white text-teal-dark px-2 py-0.5 rounded-full border border-teal-dark/10">
                              Caregiver Notified
                            </span>
                          )}
                        </div>
                        <h4 className="text-sm font-bold text-teal-dark">{al.title}</h4>
                        <p className="text-xs text-teal-dark/85 leading-relaxed">{al.message}</p>
                        <p className="text-[11px] text-teal-dark/60 font-semibold">{al.clinician_target}</p>
                      </div>
                    </div>

                    {/* Acknowledge Button */}
                    <div className="flex-shrink-0">
                      {al.is_acknowledged ? (
                        <span className="inline-flex items-center gap-1 text-xs font-semibold text-teal-dark/60 bg-white/70 px-3 py-1.5 rounded-full">
                          <CheckCircle2 className="w-3.5 h-3.5 text-mint-dark" /> Acknowledged
                        </span>
                      ) : (
                        <button
                          onClick={() => handleAcknowledge(al.id)}
                          className="px-4 py-2 bg-teal-dark hover:bg-teal-light text-white text-xs font-bold rounded-full shadow-pill transition-all"
                        >
                          Mark Acknowledged
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* SECTION 2: Clinician-Approved Thresholds Table / Cards */}
      <div className="bg-white rounded-card p-6 border border-teal-dark/10 shadow-soft space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-teal-dark/10 pb-3 gap-2">
          <div>
            <h2 className="text-lg font-bold text-teal-dark">Clinician Calibrated Boundaries</h2>
            <p className="text-xs text-teal-dark/60">
              {isDoctor 
                ? "You have doctor role permissions to edit and approve chronic alert thresholds." 
                : "Thresholds certified by your attending physician. Only doctor role can adjust targets."}
            </p>
          </div>
          {!isDoctor && (
            <span className="inline-flex items-center gap-1 text-xs font-medium text-teal-dark/60 bg-canvas-subtle px-3 py-1 rounded-full">
              <Lock className="w-3 h-3" /> Doctor Protected
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {thresholds.map((t) => {
            const isEditing = editingId === t.id;
            return (
              <div
                key={t.id}
                className="p-5 rounded-2xl bg-canvas-subtle/70 border border-teal-dark/10 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-teal-dark text-base capitalize">
                      {t.metric_type.replace(/_/g, ' ')}
                    </span>
                    <span className="text-xs font-bold bg-white text-teal-dark px-2 py-0.5 rounded-full border border-teal-dark/10">
                      {t.unit}
                    </span>
                  </div>

                  {isDoctor && !isEditing && (
                    <button
                      onClick={() => handleStartEdit(t)}
                      className="inline-flex items-center gap-1 text-xs font-bold text-teal-dark hover:text-teal-light bg-white px-2.5 py-1 rounded-full border border-teal-dark/15 shadow-sm"
                    >
                      <Edit3 className="w-3 h-3" /> Edit
                    </button>
                  )}
                </div>

                {isEditing ? (
                  <div className="space-y-3 pt-2">
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div>
                        <label className="block text-[10px] font-bold text-teal-dark/70 mb-1">Target Max</label>
                        <input
                          type="number"
                          value={editValues.target_max}
                          onChange={(e) => setEditValues({ ...editValues, target_max: parseFloat(e.target.value) })}
                          className="w-full p-2 rounded-xl border border-teal-dark/20 text-xs font-bold"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-teal-dark/70 mb-1">Warning Max</label>
                        <input
                          type="number"
                          value={editValues.warning_max}
                          onChange={(e) => setEditValues({ ...editValues, warning_max: parseFloat(e.target.value) })}
                          className="w-full p-2 rounded-xl border border-teal-dark/20 text-xs font-bold"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-teal-dark/70 mb-1">Critical Max</label>
                        <input
                          type="number"
                          value={editValues.critical_max}
                          onChange={(e) => setEditValues({ ...editValues, critical_max: parseFloat(e.target.value) })}
                          className="w-full p-2 rounded-xl border border-teal-dark/20 text-xs font-bold"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-teal-dark/70 mb-1">Clinical Rationale</label>
                      <input
                        type="text"
                        value={editValues.clinical_rationale}
                        onChange={(e) => setEditValues({ ...editValues, clinical_rationale: e.target.value })}
                        className="w-full p-2 rounded-xl border border-teal-dark/20 text-xs font-medium"
                      />
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => handleSaveThreshold(t.id)}
                        className="px-4 py-1.5 bg-teal-dark text-white text-xs font-bold rounded-full shadow-pill"
                      >
                        Approve & Save
                      </button>
                      <button
                        onClick={() => setEditingId(null)}
                        className="px-3 py-1.5 bg-gray-200 text-gray-700 text-xs font-bold rounded-full"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="bg-mint/40 p-2.5 rounded-xl border border-mint">
                        <span className="text-[10px] font-bold text-teal-dark/70 block uppercase">Target Range</span>
                        <span className="text-xs font-black text-teal-dark">
                          {t.target_min || 0} - {t.target_max}
                        </span>
                      </div>
                      <div className="bg-coral/20 p-2.5 rounded-xl border border-coral/30">
                        <span className="text-[10px] font-bold text-coral-dark block uppercase">Warning Zone</span>
                        <span className="text-xs font-black text-teal-dark">
                          &gt; {t.warning_max}
                        </span>
                      </div>
                      <div className="bg-coral-critical/15 p-2.5 rounded-xl border border-coral-critical/30">
                        <span className="text-[10px] font-bold text-coral-critical block uppercase">Critical Zone</span>
                        <span className="text-xs font-black text-coral-critical">
                          &gt; {t.critical_max}
                        </span>
                      </div>
                    </div>

                    {t.clinical_rationale && (
                      <p className="text-xs text-teal-dark/80 bg-white p-3 rounded-xl border border-teal-dark/5">
                        <strong>Clinical Rationale: </strong> {t.clinical_rationale}
                      </p>
                    )}

                    <div className="flex items-center justify-between text-[11px] text-teal-dark/60 pt-2 border-t border-teal-dark/5">
                      <span className="flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-mint-dark" />
                        Approved by {t.approved_by_name}
                      </span>
                      <span>Certified</span>
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
